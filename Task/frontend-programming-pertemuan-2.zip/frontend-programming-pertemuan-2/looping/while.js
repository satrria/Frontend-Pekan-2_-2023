// membuat variable awal
let i = 1;

/**
 * Looping menggunakan while.
 * Membuat kondisi untuk batasan looping.
 */
while (i < 11) {
  console.log(`Perulangan ke: ${i}`);
  // melakukan increment
  i++;
}
