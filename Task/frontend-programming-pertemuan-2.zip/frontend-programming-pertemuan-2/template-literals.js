const name = "Aufa Billah";
const bod = 2001;

/**
 * Membuat string menggunakan template literals.
 * Dapat menggunakan multiline.
 * Dapat melakukan interpolasi.
 */
const greeting = `
Hello, my name ${name}.
Umur saya ${2022 - bod}
`;

console.log(greeting);
